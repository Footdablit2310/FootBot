"""Config handling file"""

from typing import Optional
import discord
from discord.ext import commands
from discord import app_commands
from utils.storage import (
    get_guild_data_l,
    set_guild_data_l,
    command_list_add,
    LEADERBOARD
)
from utils.validator import validate_interaction_guild, validate_permissions_r


class Config(commands.Cog):
    """The config class"""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(
        name="add-permissions-leaderboard",
        description="Add a role or member to permissions",
    )
    async def add_permissions_leaderboard(
        self,
        interaction: discord.Interaction,
        role: Optional[discord.Role] = None,
        member: Optional[discord.Member] = None,
    ):
        """Adds permissions"""
        if not validate_permissions_r(interaction):
            await interaction.response.send_message(
                "You do not have access to this command!", ephemeral=True
            )
            return

        guild = validate_interaction_guild(interaction)
        GUILD_ID = guild.id
        data = get_guild_data_l(GUILD_ID)
        permissions_config: dict[str, list[int]] = data["config"]["permissions"]

        if role:
            permissions_config["roles"].append(role.id)
        if member:
            permissions_config["members"].append(member.id)

        set_guild_data_l(GUILD_ID, data)
        role_mentions: list[str] = []
        for rid in permissions_config["roles"]:
            role = guild.get_role(rid)
            if role is not None:
                role_mentions.append(role.mention)
            else:
                role_mentions.append(f"❌ Invalid role {rid}")

        member_mentions: list[str] = []
        for mid in permissions_config["members"]:
            member = guild.get_member(mid)
            if member is not None:
                member_mentions.append(member.mention)
            else:
                member_mentions.append(f"❌ Invalid member {mid}")

        # Build response with mentions
        if role or member:
            msg = "⚙️ Added permissions:\n"
        else:
            msg = "⚙️ Current permissions:\n"

        msg = (
            f"Roles: {', '.join(role_mentions) if role_mentions else 'None'}\n"
            f"Members: {', '.join(member_mentions) if member_mentions else 'None'}"
        )

        await interaction.response.send_message(msg, ephemeral=True)

    @app_commands.command(
        name="remove_permissions-leaderboard",
        description="Remove a role or member from permissions",
    )
    async def remove_permissions_leaderboard(
        self,
        interaction: discord.Interaction,
        role: Optional[discord.Role] = None,
        member: Optional[discord.Member] = None,
    ):
        """Removes permissions"""
        if not validate_permissions_r(interaction):
            await interaction.response.send_message(
                "You do not have access to this command!", ephemeral=True
            )
            return

        guild = validate_interaction_guild(interaction)
        GUILD_ID = guild.id
        data = get_guild_data_l(GUILD_ID)
        permissions_config: dict[str, list[int]] = data["config"]["permissions"]

        if role and role.id in permissions_config["roles"]:
            permissions_config["roles"].remove(role.id)
        if member and member.id in permissions_config["members"]:
            permissions_config["members"].remove(member.id)

        set_guild_data_l(GUILD_ID, data)
        role_mentions: list[str] = []
        for rid in permissions_config["roles"]:
            role = guild.get_role(rid)
            if role is not None:
                role_mentions.append(role.mention)
            else:
                role_mentions.append(f"❌ Invalid role {rid}")

        member_mentions: list[str] = []
        for mid in permissions_config["members"]:
            member = guild.get_member(mid)
            if member is not None:
                member_mentions.append(member.mention)
            else:
                member_mentions.append(f"❌ Invalid member {mid}")

        if role or member:
            msg = "⚙️ Removed permissions:\n"
        else:
            msg = "⚙️ Current permissions:\n"

        msg = (
            f"Roles: {', '.join(role_mentions) if role_mentions else 'None'}\n"
            f"Members: {', '.join(member_mentions) if member_mentions else 'None'}"
        )

        await interaction.response.send_message(msg, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    """Prepares Bot"""
    command_list_add(Config.add_permissions_leaderboard.name, LEADERBOARD)
    command_list_add(Config.remove_permissions_leaderboard.name, LEADERBOARD)

    await bot.add_cog(Config(bot))
